-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
<h1>INDEX</h1>

<h4> --> Introduction</h4>

<h4> --> Our Goal</h4>

<h4> --> Improvements</h4>

<h4> --> Programs to Use</h4>

<h4> --> Roadmap</h4>

<h4> --> Terms of Use

<h4> --> Contact Us</h4>

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------



<h2># Introduction</h2>

<p>Hello and thanks for reading this file! This file will show you everything we have in mind for this project about a quiz, and also some more extras!</p>

<h2># Our Goal</h2>

<p>This project has as it's goal to make a quiz on an android enviroment with the recouse of "Android Studio" in order to test our users knowledge, make some fun tests, get little competitions within our userbase or just for them to have a little fun! In order to achieve this, we will use the programming language "JAVA" for the code hitself, with some touch of HTML, CSS AND JAVASCRIPT in order to create a little introductory website. In the future, we are also planning to make a highly improved website to maybe show our uses. With this project, we hope to bring some fun to our users and improve our as much as possible our capabilities in this area. </p>

<h2># Improvements</h2>

<p>This quiz is some sort of "upgrade" to our lattest project, which was the same quiz, but on console with less features. It will be available on another repository, which is this one: (https://github.com/JustaStudent01/QuizConsoleApp). With this new project, we hope to improve some features and even add some more, create a good interface for the app, add a multiplayer gamemode, have a better login/accounts system, etc.</p>

<h2># Programs to use</h2>

<p>GitHub, Android Studio, VisualStudioCode, ROOM database (SQLite), Adobe Ilustrator</p>

<h2># Roadmap</h2>

<p>1. Analyse the problem</p>
<p>2. Order the tasks to do among the members and find the solution to the problem</p>
<p>3. Begin to solve the problem and add features</p>
<p> 4. (...)</p>
   
<h2># --> Terms of Use
   
<p> We allow any user to try and have some fun with this project, when its complete or even before it's whole completion. Aditionally, we do NOT allow any plagiarism of our code, terms or any data inside this repository, however using this code as a way to better understand or assist in any matter you may have with your projects is allowed. Just do not copy our hard work!     
      
<h2># Contact us!</h2>

<p>From doubts to improvements, we are open to it all! Don't worry if we take long to respond, we might be coding or doing outside works in this project.</p>

<p>24290@stu.ipbeja.pt | 
24288@stu.ipbeja.pt</p>
